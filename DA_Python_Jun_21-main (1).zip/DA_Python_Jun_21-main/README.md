# DATA ANALYTICS WITH PYTHON NATIONAL WORKSHOP
Hi I attended 1-Week National Workshop on "Data Analytics With Python" from 21-26 June 2021, conducted by <b> THE CODE SCHOLAR</b>.

<br>I got to have hands on experience on:
<li>Python
<li>Maths Operations
<li>Data Massaging and Cleaning
<li>Machine Learning
<li>Visualization Techniques
<li>Project Understanding
<br><br>
During this 1-Week, everything was explained from the very basics so that
anyone with zero experience on programming can learn.
  
The instructor during the session was Mr. Nitesh. 
<br>Speakers from different industry domains, lightened up the session with their experience. 
I got to learn a lot during this 1-Week and  it was an amazing experience learning with THE CODE SCHOLAR.<br>

<br><br>Here's the link for you to watch the sessions as well<br>
 
<a href="https://youtube.com/playlist?list=PL3Hnv9OFTJvXgKw-XWGLbUEkDNEk4Tg7F"> <img src="https://github.com/thecodescholar/DA_Python_Jun_21/blob/main/PYTHON%20AND%20MACHINE%20LEARNING.png"> </a>


I enjoyed this 1-Week, you can as well. To register for next free 1-Week, bootcamp, visit:
<a href="http://www.thecodescholar.com"> www.thecodescholar.com </a>
or follow THE CODE SCHOLAR on:
<li><a href=
"https://linkedin.com/company/the-code-scholar">LinkedIn</a>
<li><a href=
"https://www.instagram.com/thecodescholar">Instagram</a>
<li><a href=
"https://youtube.com/channel/UCyG-UNr0u8rIb3Dxq2TAZ9A">YouTube</a>
<li><a href=
"https://github.com/thecodescholar">GitHub</a>
<li><a href=
"https://twitter.com/thecodescholar_">Twitter</a>

